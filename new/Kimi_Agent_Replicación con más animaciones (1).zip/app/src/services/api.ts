import type { Registro, DashboardStats, LoginCredentials, User, Curso, InscripcionCurso } from '@/types'
import { mockRegistros, mockStats, mockUser } from '@/data/mockData'
import { mockCursos, mockInscripciones, getCursosFiltrados, getInscripcionesPorCurso, inscribirACurso } from '@/data/cursosMock'

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms))

// ============================
// AUTH
// ============================
export async function login(credentials: LoginCredentials): Promise<{ user: User; token: string }> {
  await delay(800)
  if (credentials.correo === 'admin@acoes.local' && credentials.contrasena === 'Admin1234!') {
    return { user: mockUser, token: 'mock-jwt-token' }
  }
  throw new Error('Credenciales incorrectas')
}

export async function getCurrentUser(): Promise<User | null> {
  await delay(300)
  const token = localStorage.getItem('token')
  if (!token) return null
  return mockUser
}

export function logout(): void {
  localStorage.removeItem('token')
}

// ============================
// REGISTROS (Personas)
// ============================
export async function getRegistros(params?: {
  search?: string
  departamento?: string
  funcion?: string
  estado?: string
  page?: number
  limit?: number
}): Promise<{ data: Registro[]; total: number }> {
  await delay(500)
  let data = [...mockRegistros]
  if (params?.search) {
    const s = params.search.toLowerCase()
    data = data.filter(r => r.nombre.toLowerCase().includes(s) || r.dui.toLowerCase().includes(s) || r.correo.toLowerCase().includes(s))
  }
  if (params?.departamento) data = data.filter(r => r.departamento === params.departamento)
  if (params?.funcion) data = data.filter(r => r.funcion === params.funcion)
  if (params?.estado) data = data.filter(r => r.estado === params.estado)
  const page = params?.page || 1
  const limit = params?.limit || 10
  const start = (page - 1) * limit
  return { data: data.slice(start, start + limit), total: data.length }
}

export async function getRegistro(id: string): Promise<Registro> {
  await delay(300)
  const r = mockRegistros.find(r => r.id === id)
  if (!r) throw new Error('Registro no encontrado')
  return r
}

export async function createRegistro(data: Omit<Registro, 'id' | 'codigo' | 'fechaRegistro' | 'estado'>): Promise<Registro> {
  await delay(800)
  const newReg: Registro = { ...data, id: String(mockRegistros.length + 1), codigo: `ACO-2024-${String(mockRegistros.length + 1).padStart(3, '0')}`, fechaRegistro: new Date().toISOString().split('T')[0], estado: 'activo' }
  mockRegistros.unshift(newReg)
  return newReg
}

export async function deleteRegistro(id: string): Promise<void> {
  await delay(400)
  const i = mockRegistros.findIndex(r => r.id === id)
  if (i !== -1) mockRegistros.splice(i, 1)
}

// ============================
// CURSOS
// ============================
export async function getCursos(params?: { categoria?: string; nivel?: string; estado?: string; search?: string }): Promise<Curso[]> {
  await delay(400)
  return getCursosFiltrados(params?.categoria, params?.nivel, params?.estado, params?.search)
}

export async function getCurso(id: string): Promise<Curso> {
  await delay(300)
  const c = mockCursos.find(c => c.id === id)
  if (!c) throw new Error('Curso no encontrado')
  return c
}

export async function createCurso(data: Omit<Curso, 'id' | 'inscritos' | 'fechaRegistro'>): Promise<Curso> {
  await delay(600)
  const newCurso: Curso = { ...data, id: String(mockCursos.length + 1), inscritos: 0, fechaRegistro: new Date().toISOString().split('T')[0] }
  mockCursos.push(newCurso)
  return newCurso
}

export async function updateCurso(id: string, data: Partial<Curso>): Promise<Curso> {
  await delay(400)
  const i = mockCursos.findIndex(c => c.id === id)
  if (i === -1) throw new Error('Curso no encontrado')
  mockCursos[i] = { ...mockCursos[i], ...data }
  return mockCursos[i]
}

export async function deleteCurso(id: string): Promise<void> {
  await delay(300)
  const i = mockCursos.findIndex(c => c.id === id)
  if (i !== -1) mockCursos.splice(i, 1)
}

// ============================
// INSCRIPCIONES A CURSOS
// ============================
export async function getInscripciones(cursoId: string): Promise<InscripcionCurso[]> {
  await delay(300)
  return getInscripcionesPorCurso(cursoId)
}

export async function inscribir(data: Omit<InscripcionCurso, 'id' | 'fechaInscripcion' | 'estado'>): Promise<InscripcionCurso> {
  await delay(600)
  const curso = mockCursos.find(c => c.id === data.cursoId)
  if (!curso) throw new Error('Curso no encontrado')
  if (curso.inscritos >= curso.cupoMaximo) throw new Error('El curso ha alcanzado su cupo máximo')
  return inscribirACurso(data)
}

export async function cancelarInscripcion(id: string): Promise<void> {
  await delay(300)
  const i = mockInscripciones.findIndex(ins => ins.id === id)
  if (i !== -1) {
    const ins = mockInscripciones[i]
    const curso = mockCursos.find(c => c.id === ins.cursoId)
    if (curso) {
      curso.inscritos = Math.max(0, curso.inscritos - 1)
      if (curso.estado === 'lleno' && curso.inscritos < curso.cupoMaximo) {
        curso.estado = 'abierto'
      }
    }
    mockInscripciones[i].estado = 'cancelada'
  }
}

// ============================
// DASHBOARD STATS
// ============================
export async function getDashboardStats(): Promise<DashboardStats> {
  await delay(400)
  return {
    ...mockStats,
    totalCursos: mockCursos.length,
    cursosActivos: mockCursos.filter(c => c.estado === 'abierto').length,
    inscripciones: mockInscripciones.length,
    cuposDisponibles: mockCursos.reduce((sum, c) => sum + (c.cupoMaximo - c.inscritos), 0),
    cursosPorCategoria: [
      { name: 'Colorimetría', value: 1 },
      { name: 'Corte', value: 1 },
      { name: 'Manicure', value: 1 },
      { name: 'Maquillaje', value: 1 },
      { name: 'Tratamientos', value: 1 },
      { name: 'Barbería', value: 1 },
    ],
    inscripcionesPorCurso: mockCursos.map(c => ({ name: c.nombre.split(' ').slice(0, 3).join(' '), inscritos: c.inscritos, cupo: c.cupoMaximo })),
  }
}

// ============================
// EXPORT
// ============================
export function exportToCSV(registros: Registro[]): void {
  const data = registros.map(r => ({ Codigo: r.codigo, Nombre: r.nombre, DUI: r.dui, Celular: r.celular, Correo: r.correo, Departamento: r.departamento, Funcion: r.funcion, Fecha: r.fechaRegistro, Estado: r.estado }))
  const csv = [Object.keys(data[0]).join(','), ...data.map(row => Object.values(row).join(','))].join('\n')
  const blob = new Blob([csv], { type: 'text/csv' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `ACOES_Registros_${new Date().toISOString().split('T')[0]}.csv`
  a.click()
}
