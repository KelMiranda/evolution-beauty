import { useRef } from 'react'
import { useGSAP } from '@gsap/react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { ProjectCard } from '@/components/ProjectCard'
import { SectionLabel } from '@/components/SectionLabel'
import { MagneticButton } from '@/components/MagneticButton'

gsap.registerPlugin(ScrollTrigger)

const projects = [
  {
    image: '/images/project-gage.jpg',
    client: 'GAGE',
    title: 'The first work social platform for the ones who clock in.',
    description: 'Accelerating a Techstars-backed startup transforming shift worker recognition with a complete mobile app, web platform, and website\u2014plus customer support and ongoing product innovation.',
    tags: ['Mobile App', 'Web App', 'Website'],
  },
  {
    image: '/images/project-franklinwh.jpg',
    client: 'FranklinWH',
    title: 'AI Powering Clean Energy.',
    description: 'Powering a Sequoia Capital-backed leader in residential energy storage with AI-driven sales automation, intelligent customer service solutions, and strategic IT staffing to accelerate national market expansion.',
    tags: ['AI Solutions', 'IT Staffing'],
  },
  {
    image: '/images/project-missuniverse.jpg',
    client: 'Miss Universe',
    title: 'Behind the Crown.',
    description: 'Implementing a real-time multilingual interpretation solution for the world\'s premier beauty pageant in El Salvador, with end-to-end on-site technical support.',
    tags: ['Mobile App'],
  },
]

export function WorkSection() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useGSAP(() => {
    // Section label slide
    gsap.from('.work-section-label', {
      opacity: 0,
      y: 20,
      duration: 0.6,
      ease: 'power3.out',
      scrollTrigger: {
        trigger: '.work-section-label',
        start: 'top 85%',
      },
    })

    // Title character animation
    const titleChars = sectionRef.current?.querySelectorAll('.work-title-char')
    if (titleChars) {
      gsap.from(titleChars, {
        opacity: 0,
        y: 80,
        rotateX: -80,
        duration: 0.8,
        stagger: 0.03,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: '.work-title',
          start: 'top 80%',
        },
      })
    }

    // Subtitle words
    gsap.from('.work-subtitle', {
      opacity: 0,
      y: 30,
      duration: 0.7,
      ease: 'power3.out',
      scrollTrigger: {
        trigger: '.work-subtitle',
        start: 'top 85%',
      },
    })

    // Project cards - each with parallax and reveal
    const cards = sectionRef.current?.querySelectorAll('.project-card-wrapper')
    cards?.forEach((card, i) => {
      // Parallax on the image
      const img = card.querySelector('.project-bg')
      if (img) {
        gsap.to(img, {
          yPercent: 15,
          ease: 'none',
          scrollTrigger: {
            trigger: card,
            start: 'top bottom',
            end: 'bottom top',
            scrub: true,
          },
        })
      }

      // Card reveal
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: card,
          start: 'top 80%',
          toggleActions: 'play none none none',
        },
      })

      tl.from(card, {
        opacity: 0,
        y: 100,
        scale: 0.95,
        duration: 1,
        delay: i * 0.1,
        ease: 'power3.out',
      })
      .from(card.querySelector('.project-overlay'), {
        opacity: 0,
        x: -40,
        duration: 0.8,
        ease: 'power3.out',
      }, '-=0.6')
      .from(card.querySelectorAll('.project-tag'), {
        opacity: 0,
        y: 10,
        scale: 0.9,
        duration: 0.4,
        stagger: 0.08,
        ease: 'back.out(1.7)',
      }, '-=0.4')
    })

    // View all button
    gsap.from('.work-cta-btn', {
      opacity: 0,
      y: 30,
      scale: 0.95,
      duration: 0.6,
      ease: 'back.out(1.7)',
      scrollTrigger: {
        trigger: '.work-cta-btn',
        start: 'top 90%',
      },
    })
  }, { scope: sectionRef })

  const titleText = "Work"

  return (
    <section ref={sectionRef} id="work" className="py-12 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="work-section-label">
          <SectionLabel 
            left="BRAGGING? MAYBE. PROUD? ABSOLUTELY" 
            right="[CASE STUDIES]" 
          />
        </div>

        <div className="mt-16 flex flex-col md:flex-row md:items-end md:justify-between gap-6">
          <h2 className="work-title text-5xl md:text-7xl font-light text-white tracking-tight" style={{ perspective: '1000px' }}>
            {titleText.split('').map((char, i) => (
              <span key={i} className="work-title-char inline-block" style={{ transformStyle: 'preserve-3d' }}>
                {char}
              </span>
            ))}
            <sup className="text-lg md:text-xl text-[#555555] ml-2 inline-block work-title-char">[2]</sup>
          </h2>
          <p className="work-subtitle text-[15px] text-[#8a8a8a] max-w-sm">
            Built for clients who dared to think differently and trusted us with their vision of a masterpiece.
          </p>
        </div>

        <div className="mt-16 space-y-8">
          {projects.map((project, i) => (
            <div key={i} className="project-card-wrapper">
              <ProjectCard {...project} />
            </div>
          ))}
        </div>

        <div className="flex justify-center mt-12">
          <MagneticButton
            strength={0.3}
            className="work-cta-btn inline-flex items-center gap-2 px-5 py-2.5 border border-[#333] rounded-md text-sm font-medium text-white hover:bg-white hover:text-[#050505] transition-all duration-300"
          >
            <span className="w-1 h-1 rounded-full bg-white" />
            View all projects
          </MagneticButton>
        </div>
      </div>
    </section>
  )
}
