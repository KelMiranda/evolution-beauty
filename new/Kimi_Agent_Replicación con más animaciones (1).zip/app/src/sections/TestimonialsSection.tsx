import { useRef } from 'react'
import { useGSAP } from '@gsap/react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { TestimonialCard } from '@/components/TestimonialCard'
import { MagneticButton } from '@/components/MagneticButton'

gsap.registerPlugin(ScrollTrigger)

const testimonials = [
  {
    quote: "You're doing great work. As the pressure ramps up, what matters most is consistent, fast progress, and that's exactly what Aracari delivers. I'm all in.",
    author: 'Justin Henshaw',
    title: 'CEO, GAGE',
    image: '/images/author-justin.jpg',
  },
  {
    quote: "Thank you for all the support. We're really happy we chose to work with Aracari; it was a great decision.",
    author: 'Gonzalo Guarnaschelli',
    title: 'CEO, YHAT',
    image: '/images/author-gonzalo.jpg',
  },
  {
    quote: "Aracari were always ahead of schedule and even identified new and innovative ideas that our team was not even aware of as a possibility.",
    author: 'Cameron Plese',
    title: 'Head of Government Affairs & North America, RSPO',
    image: '/images/author-cameron.jpg',
  },
  {
    quote: "Aracari Studios exceeded our expectations by combining creative vision with flawless execution. They got involved with strong judgment and a level of proactivity that truly made a difference.",
    author: 'Claudia Cifuentes',
    title: 'Executive Director, ESINTEC',
    image: '/images/author-claudia.jpg',
  },
]

export function TestimonialsSection() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useGSAP(() => {
    // Top label
    gsap.from('.testimonials-top-label', {
      opacity: 0,
      y: 20,
      duration: 0.6,
      ease: 'power3.out',
      scrollTrigger: {
        trigger: '.testimonials-top-label',
        start: 'top 85%',
      },
    })

    // Clutch badge bounce in
    gsap.from('.clutch-badge', {
      opacity: 0,
      y: 30,
      scale: 0.9,
      duration: 0.7,
      ease: 'back.out(1.7)',
      scrollTrigger: {
        trigger: '.clutch-badge',
        start: 'top 85%',
      },
    })

    // Title character animation
    const titleChars = sectionRef.current?.querySelectorAll('.testi-title-char')
    if (titleChars) {
      gsap.from(titleChars, {
        opacity: 0,
        y: 100,
        rotateX: -90,
        duration: 0.9,
        stagger: 0.025,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: '.testimonials-title',
          start: 'top 80%',
        },
      })
    }

    // Get in touch button
    gsap.from('.testi-cta', {
      opacity: 0,
      y: 20,
      scale: 0.95,
      duration: 0.5,
      ease: 'back.out(1.7)',
      scrollTrigger: {
        trigger: '.testi-cta',
        start: 'top 90%',
      },
    })

    // Testimonial cards with dramatic stagger
    const cards = sectionRef.current?.querySelectorAll('.testimonial-card-wrapper')
    cards?.forEach((card, i) => {
      gsap.from(card, {
        opacity: 0,
        y: 80,
        rotateY: i % 2 === 0 ? -10 : 10,
        duration: 0.8,
        delay: i * 0.15,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: card,
          start: 'top 85%',
          toggleActions: 'play none none none',
        },
      })

      // Quote text fade
      const quote = card.querySelector('.quote-text')
      if (quote) {
        gsap.from(quote, {
          opacity: 0,
          y: 20,
          duration: 0.6,
          delay: i * 0.15 + 0.3,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: card,
            start: 'top 85%',
            toggleActions: 'play none none none',
          },
        })
      }
    })
  }, { scope: sectionRef })

  const titleText = "Testimonials"

  return (
    <section ref={sectionRef} className="py-24 md:py-32 px-6">
      <div className="max-w-6xl mx-auto">
        {/* Top Label */}
        <div className="testimonials-top-label flex items-center justify-between py-6 border-b border-[#1a1a1a]">
          <span className="font-mono text-[11px] tracking-[0.1em] text-[#555555] uppercase">
            What earned trust sounds like
          </span>
          <span className="font-mono text-[11px] tracking-[0.1em] text-[#555555]">
            [TESTIMONIALS]
          </span>
        </div>

        <div className="mt-16 text-center">
          {/* Clutch Badge */}
          <a 
            href="https://clutch.co/profile/aracari-studios" 
            target="_blank" 
            rel="noopener noreferrer"
            className="clutch-badge inline-flex items-center gap-2 px-4 py-2 border border-[#333] rounded-full text-[12px] text-[#8a8a8a] hover:border-[#555] hover:scale-105 transition-all duration-300"
          >
            <span className="font-semibold text-white">Clutch</span>
            <span className="text-yellow-500">★ 5.0</span>
            <span>AVERAGE REVIEW RATING</span>
          </a>

          <h2 
            className="testimonials-title mt-8 text-5xl md:text-7xl font-light text-white tracking-tight" 
            style={{ perspective: '1000px' }}
          >
            {titleText.split('').map((char, i) => (
              <span 
                key={i} 
                className="testi-title-char inline-block" 
                style={{ transformStyle: 'preserve-3d' }}
              >
                {char}
              </span>
            ))}
            <sup className="testi-title-char text-lg md:text-xl text-[#555555] ml-2 inline-block">[3]</sup>
          </h2>

          <MagneticButton
            strength={0.3}
            href="#contact"
            className="testi-cta mt-8 inline-flex items-center gap-2 px-5 py-2.5 border border-[#333] rounded-md text-sm font-medium text-white hover:bg-white hover:text-[#050505] transition-all duration-300"
          >
            <span className="w-1 h-1 rounded-full bg-white" />
            Get in touch
          </MagneticButton>
        </div>

        {/* Testimonials Grid - Staggered */}
        <div className="mt-16 grid md:grid-cols-2 gap-6" style={{ perspective: '1000px' }}>
          {/* Left column */}
          <div className="space-y-6">
            {testimonials.filter((_, i) => i % 2 === 0).map((t, i) => (
              <div key={i} className="testimonial-card-wrapper" style={{ transformStyle: 'preserve-3d' }}>
                <TestimonialCard {...t} />
              </div>
            ))}
          </div>
          {/* Right column - offset */}
          <div className="space-y-6 md:mt-12">
            {testimonials.filter((_, i) => i % 2 === 1).map((t, i) => (
              <div key={i} className="testimonial-card-wrapper" style={{ transformStyle: 'preserve-3d' }}>
                <TestimonialCard {...t} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
