import { useRef } from 'react'
import { useGSAP } from '@gsap/react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { ServiceBlock } from '@/components/ServiceBlock'
import { SectionLabel } from '@/components/SectionLabel'

gsap.registerPlugin(ScrollTrigger)

const services = [
  {
    number: '01',
    title: 'Custom Software Development',
    subtitle: 'Software that actually works. No fluff, no excuses.',
    description: 'We blur the line between tech partner and business advisor. We challenge assumptions, ask hard questions, and build software that solves real business problems. From MVP validation to scaling your platform, we\'re in it with you\u2014strategy, execution, everything.',
    categories: [
      'Mobile Applications (iOS & Android)',
      'Web Applications & SaaS Platforms',
      'Enterprise Software & Integrations',
      'API Development & Backend Development',
      'Website Development',
    ],
    cta: "Let's ship your next app",
  },
  {
    number: '02',
    title: 'Staff Augmentation',
    subtitle: 'The exact team you need, when you need it.',
    description: 'We design custom staffing strategies that flex with your business. Tell us what you\'re building and where you\'re headed. We\'ll architect a team solution\u2014whether that\'s a process automation specialist backed by our full tech team, a full development squad, or wraparound support like QA, DevOps, or customer service.',
    categories: [
      'Software Engineers (Full-stack, Frontend, Backend)',
      'Mobile Developers (iOS & Android)',
      'Product & Design (PM, UX/UI, Product Owners)',
      'DevOps & Cloud Engineers',
      'Quality Assurance & Testing',
      'Operations Support (Customer Service, Virtual Assistants)',
    ],
    cta: "Let's build your new favorite team",
  },
  {
    number: '03',
    title: 'AI & Automation',
    subtitle: 'Automate the boring stuff. Focus on what matters.',
    description: 'We help businesses eliminate manual work and scale operations with AI. From custom chatbots to workflow automation and AI integration, we build solutions that save time, reduce costs, and free your team to focus on high-value work. No hype, no theoretical AI, just practical automation that delivers measurable results.',
    categories: [
      'Workflow & Process Automation',
      'Custom AI Chatbots & Virtual Assistants',
      'AI Integration & Implementation',
      'Robotic Process Automation (RPA)',
    ],
    cta: "Let's automate that for you",
  },
]

export function ServicesSection() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useGSAP(() => {
    // Header animation
    gsap.from('.service-header-label', {
      opacity: 0,
      x: -30,
      duration: 0.6,
      ease: 'power3.out',
      scrollTrigger: {
        trigger: '.service-header-label',
        start: 'top 85%',
      },
    })

    gsap.from('.service-header-text', {
      opacity: 0,
      y: 50,
      duration: 0.8,
      ease: 'power3.out',
      scrollTrigger: {
        trigger: '.service-header-text',
        start: 'top 80%',
      },
    })

    // Service blocks entrance
    const blocks = sectionRef.current?.querySelectorAll('.service-block-wrapper')
    blocks?.forEach((block) => {
      const number = block.querySelector('.service-number')
      const title = block.querySelector('.service-title')
      const subtitle = block.querySelector('.service-subtitle')
      const desc = block.querySelector('.service-desc')
      const btn = block.querySelector('.service-btn')
      const catItems = block.querySelectorAll('.cat-item')

      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: block,
          start: 'top 75%',
          toggleActions: 'play none none none',
        },
      })

      tl.from(number, { opacity: 0, x: -20, duration: 0.5, ease: 'power3.out' })
        .from(title, { opacity: 0, y: 40, duration: 0.7, ease: 'power3.out' }, '-=0.3')
        .from(subtitle, { opacity: 0, y: 20, duration: 0.5, ease: 'power3.out' }, '-=0.4')
        .from(desc, { opacity: 0, y: 30, duration: 0.6, ease: 'power3.out' }, '-=0.3')
        .from(catItems, { opacity: 0, x: 20, duration: 0.4, stagger: 0.08, ease: 'power3.out' }, '-=0.4')
        .from(btn, { opacity: 0, y: 20, scale: 0.95, duration: 0.5, ease: 'back.out(1.7)' }, '-=0.2')
    })
  }, { scope: sectionRef })

  return (
    <section ref={sectionRef} id="services" className="py-12 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="service-header-label">
          <SectionLabel left="Services" />
        </div>
        <h2 className="service-header-text text-4xl md:text-5xl font-light text-white mt-6 tracking-tight leading-tight">
          Designed to guarantee business momentum. Built to sustain it.
        </h2>
      </div>

      {services.map((service) => (
        <div key={service.number} className="service-block-wrapper">
          <ServiceBlock {...service} />
        </div>
      ))}
    </section>
  )
}
