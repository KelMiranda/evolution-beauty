import { useRef } from 'react'
import { useGSAP } from '@gsap/react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { LogoCard } from '@/components/LogoCard'
import { SectionLabel } from '@/components/SectionLabel'

gsap.registerPlugin(ScrollTrigger)

const clients = [
  { name: 'GAGE', row: 1 },
  { name: 'FRANKLINWH', row: 1 },
  { name: 'THE HIGH INDEX', row: 1 },
  { name: 'Y HAT', row: 2 },
  { name: 'ESINTEC', row: 2 },
  { name: 'MISS+UNIVERSE', row: 2 },
]

export function MissionSection() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useGSAP(() => {
    // Label fade in
    gsap.from('.mission-label', {
      opacity: 0,
      y: 20,
      duration: 0.6,
      ease: 'power3.out',
      scrollTrigger: {
        trigger: '.mission-label',
        start: 'top 85%',
      },
    })

    // Mission text words reveal with stagger
    const words = sectionRef.current?.querySelectorAll('.mission-word')
    if (words) {
      gsap.from(words, {
        opacity: 0,
        y: 30,
        duration: 0.8,
        stagger: 0.03,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: '.mission-text',
          start: 'top 80%',
        },
      })
    }

    // Logo cards dramatic entrance
    gsap.from('.logo-card-item', {
      opacity: 0,
      y: 60,
      rotateX: -20,
      scale: 0.9,
      duration: 0.7,
      stagger: {
        each: 0.1,
        from: 'random',
      },
      ease: 'power3.out',
      scrollTrigger: {
        trigger: '.logo-grid',
        start: 'top 80%',
      },
    })

    // Section label slide in
    gsap.from('.section-transition', {
      opacity: 0,
      y: 20,
      duration: 0.6,
      ease: 'power3.out',
      scrollTrigger: {
        trigger: '.section-transition',
        start: 'top 90%',
      },
    })
  }, { scope: sectionRef })

  const missionText = "We help exceptional teams turn ideas into real products through custom apps, AI automations, and staffing strategies designed around real business goals. From a single embedded specialist to a full squad, we scale with companies that play to win."
  const words = missionText.split(' ')

  const row1 = clients.filter(c => c.row === 1)
  const row2 = clients.filter(c => c.row === 2)

  return (
    <section ref={sectionRef} id="about" className="py-24 md:py-32 px-6">
      <div className="max-w-6xl mx-auto">
        {/* Label */}
        <span className="mission-label font-mono text-[11px] tracking-[0.1em] text-[#555555] uppercase block">
          From Elite to Elite
        </span>

        {/* Mission Text with word-by-word reveal */}
        <p className="mission-text mt-8 text-xl md:text-2xl leading-relaxed max-w-2xl">
          {words.map((word, i) => (
            <span
              key={i}
              className="mission-word inline-block mr-[0.3em]"
              style={{ 
                color: i < words.length * 0.6 
                  ? '#ffffff' 
                  : `rgba(255,255,255,${0.6 - (i - words.length * 0.6) / (words.length * 0.4) * 0.6})`
              }}
            >
              {word}
            </span>
          ))}
        </p>

        {/* Client Logo Grid */}
        <div className="logo-grid mt-20 space-y-4">
          {/* Row 1 */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {row1.map((client) => (
              <div key={client.name} className="logo-card-item">
                <LogoCard>{client.name}</LogoCard>
              </div>
            ))}
          </div>
          {/* Row 2 - Offset */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:ml-24">
            {row2.map((client) => (
              <div key={client.name} className="logo-card-item">
                <LogoCard>{client.name}</LogoCard>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Section Transition Label */}
      <div className="section-transition max-w-6xl mx-auto mt-24">
        <SectionLabel left="WHAT WE DO" right="[SERVICES]" />
      </div>
    </section>
  )
}
