import { useLiveTime } from '@/hooks/useLiveTime'
import { useScroll } from '@/hooks/useScroll'
import { useRef } from 'react'
import { useGSAP } from '@gsap/react'
import gsap from 'gsap'

export function Navbar() {
  const time = useLiveTime('America/El_Salvador')
  const scrolled = useScroll(100)
  const navRef = useRef<HTMLElement>(null)

  useGSAP(() => {
    // Nav slides down on load
    gsap.from(navRef.current, {
      y: -100,
      opacity: 0,
      duration: 0.8,
      delay: 0.2,
      ease: 'power3.out',
    })

    // Nav links stagger in
    gsap.from('.nav-link-item', {
      opacity: 0,
      y: -10,
      duration: 0.5,
      stagger: 0.05,
      delay: 0.6,
      ease: 'power3.out',
    })

    // CTA button
    gsap.from('.nav-cta', {
      opacity: 0,
      scale: 0.9,
      duration: 0.5,
      delay: 0.8,
      ease: 'back.out(1.7)',
    })
  })

  const navLinks = [
    { label: 'About', href: '#about' },
    { label: 'Services', href: '#services' },
    { label: 'Work', href: '#work' },
    { label: 'Jobs', href: '#jobs' },
  ]

  return (
    <nav 
      ref={navRef}
      className={`fixed top-0 left-0 right-0 z-50 h-16 flex items-center px-6 transition-all duration-500 ${
        scrolled 
          ? 'bg-[#050505]/90 backdrop-blur-xl border-b border-[#1a1a1a] shadow-[0_4px_30px_rgba(0,0,0,0.3)]' 
          : 'bg-transparent border-b border-[#1a1a1a]/30'
      }`}
    >
      <div className="max-w-7xl w-full mx-auto flex items-center justify-between">
        {/* Logo */}
        <a href="#" className="text-white font-bold text-sm tracking-tight hover:opacity-80 transition-opacity">
          aracari studios<sup className="text-[8px] ml-0.5">®</sup>
        </a>
        
        {/* Center - Location & Time */}
        <div className="hidden md:flex items-center gap-2 text-[13px] text-[#8a8a8a]">
          <span className="relative">
            El Salvador
            <span className="absolute -right-1.5 top-1/2 -translate-y-1/2 w-1 h-1 rounded-full bg-green-500 animate-pulse" />
          </span>
          <span className="text-[#555555] font-mono">{time}</span>
        </div>
        
        {/* Nav Links */}
        <div className="hidden md:flex items-center">
          {navLinks.map((link, i) => (
            <span key={link.label} className="nav-link-item flex items-center">
              <a 
                href={link.href} 
                className="text-[#8a8a8a] hover:text-white transition-colors duration-300 text-[13px] relative group"
              >
                {link.label}
                <span className="absolute -bottom-0.5 left-0 w-0 h-px bg-white group-hover:w-full transition-all duration-300" />
              </a>
              {i < navLinks.length - 1 && (
                <span className="text-[#555555] mx-1.5">,</span>
              )}
            </span>
          ))}
        </div>
        
        {/* CTA Button */}
        <a 
          href="#contact" 
          className="nav-cta inline-flex items-center gap-2 px-4 py-2 border border-[#333] rounded-md text-[13px] font-medium text-white hover:bg-white hover:text-[#050505] hover:border-white transition-all duration-300 hover:scale-105 active:scale-95"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
          Start a project
        </a>
      </div>
    </nav>
  )
}
