interface TestimonialCardProps {
  quote: string
  author: string
  title: string
  image: string
}

export function TestimonialCard({ quote, author, title, image }: TestimonialCardProps) {
  return (
    <div className="bg-[#0a0a0a] border border-[#1a1a1a] rounded-lg p-6 transition-all duration-500 hover:border-[#333] hover:-translate-y-2 hover:shadow-[0_20px_40px_rgba(0,0,0,0.5)]">
      <p className="quote-text text-[15px] text-white/90 leading-relaxed">
        &ldquo;{quote}&rdquo;
      </p>
      <div className="flex items-center gap-3 mt-6 pt-4 border-t border-[#1a1a1a]">
        <img 
          src={image} 
          alt={author} 
          className="w-10 h-10 rounded-full object-cover ring-2 ring-[#1a1a1a]"
        />
        <div>
          <div className="flex items-center gap-2">
            <span className="text-sm text-white font-medium">{author}</span>
            <svg className="w-4 h-4 text-blue-400" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
            </svg>
          </div>
          <span className="text-xs text-[#555555]">{title}</span>
        </div>
      </div>
    </div>
  )
}
