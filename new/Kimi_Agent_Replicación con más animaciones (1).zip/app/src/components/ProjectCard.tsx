interface ProjectCardProps {
  image: string
  client: string
  title: string
  description: string
  tags: string[]
}

export function ProjectCard({ image, client, title, description, tags }: ProjectCardProps) {
  return (
    <div className="relative w-full h-[500px] md:h-[550px] rounded-lg overflow-hidden group cursor-pointer">
      {/* Background Image with parallax */}
      <div 
        className="project-bg absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
        style={{ backgroundImage: `url(${image})`, top: '-15%', height: '130%' }}
      />
      {/* Dark Overlay */}
      <div className="absolute inset-0 bg-black/40 group-hover:bg-black/30 transition-colors duration-500" />
      
      {/* Content Panel */}
      <div className="project-overlay absolute bottom-0 left-0 md:left-8 md:bottom-8 md:max-w-md p-6 md:p-8">
        <div className="bg-black/80 backdrop-blur-sm rounded-lg p-6 md:p-8 border border-[#1a1a1a] group-hover:border-[#333] transition-all duration-500 group-hover:-translate-y-1">
          <span className="font-mono text-[11px] tracking-[0.1em] text-[#8a8a8a] uppercase">
            {client}
          </span>
          <h4 className="text-2xl md:text-3xl font-light text-white mt-3 leading-tight">
            {title}
          </h4>
          <p className="text-sm text-[#8a8a8a] mt-4 leading-relaxed">
            {description}
          </p>
          <div className="flex flex-wrap gap-2 mt-5">
            {tags.map((tag, i) => (
              <span 
                key={i} 
                className="project-tag px-3 py-1 border border-[#333] rounded-full text-xs text-[#8a8a8a] group-hover:border-[#555] group-hover:text-white transition-all duration-300"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
