import { useRef, useCallback } from 'react'
import gsap from 'gsap'

interface MagneticButtonProps {
  children: React.ReactNode
  className?: string
  strength?: number
  onClick?: () => void
  href?: string
}

export function MagneticButton({ 
  children, 
  className = '', 
  strength = 0.4,
  onClick,
  href
}: MagneticButtonProps) {
  const btnRef = useRef<HTMLDivElement>(null)
  const boundingRef = useRef<DOMRect | null>(null)

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!btnRef.current || !boundingRef.current) return
    const { clientX, clientY } = e
    const { left, top, width, height } = boundingRef.current
    const x = (clientX - left - width / 2) * strength
    const y = (clientY - top - height / 2) * strength
    
    gsap.to(btnRef.current, {
      x,
      y,
      duration: 0.4,
      ease: 'power2.out',
    })
  }, [strength])

  const handleMouseEnter = useCallback(() => {
    if (!btnRef.current) return
    boundingRef.current = btnRef.current.getBoundingClientRect()
  }, [])

  const handleMouseLeave = useCallback(() => {
    if (!btnRef.current) return
    gsap.to(btnRef.current, {
      x: 0,
      y: 0,
      duration: 0.6,
      ease: 'elastic.out(1, 0.3)',
    })
  }, [])

  const handleClick = () => {
    if (href) {
      const el = document.querySelector(href)
      el?.scrollIntoView({ behavior: 'smooth' })
    }
    onClick?.()
  }

  return (
    <div
      ref={btnRef}
      onClick={handleClick}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      className={`inline-block cursor-pointer ${className}`}
    >
      {children}
    </div>
  )
}
