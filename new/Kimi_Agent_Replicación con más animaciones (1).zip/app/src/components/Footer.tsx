export function Footer() {
  return (
    <footer className="border-t border-[#1a1a1a] py-6 px-6">
      <div className="max-w-7xl mx-auto flex items-center justify-between text-[13px] text-[#555555]">
        <span>Copyright &copy;Aracari Studios 2026</span>
        <div className="flex items-center gap-6">
          <a 
            href="https://www.linkedin.com/company/aracaristudios" 
            target="_blank" 
            rel="noopener noreferrer"
            className="hover:text-white transition-colors duration-200"
          >
            LinkedIn
          </a>
          <a 
            href="https://www.instagram.com/aracaristudios" 
            target="_blank" 
            rel="noopener noreferrer"
            className="hover:text-white transition-colors duration-200"
          >
            Instagram
          </a>
        </div>
      </div>
    </footer>
  )
}
