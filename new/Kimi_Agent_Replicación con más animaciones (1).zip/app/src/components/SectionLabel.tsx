interface SectionLabelProps {
  left: string
  right?: string
}

export function SectionLabel({ left, right }: SectionLabelProps) {
  return (
    <div className="flex items-center justify-between py-6 border-b border-[#1a1a1a]">
      <span className="font-mono text-[11px] tracking-[0.1em] text-[#555555] uppercase">
        {left}
      </span>
      {right && (
        <span className="font-mono text-[11px] tracking-[0.1em] text-[#555555]">
          {right}
        </span>
      )}
    </div>
  )
}
