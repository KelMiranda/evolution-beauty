import { ArrowUpRight } from 'lucide-react'
import { MagneticButton } from './MagneticButton'

interface ServiceBlockProps {
  number: string
  title: string
  subtitle: string
  description: string
  categories: string[]
  cta: string
}

export function ServiceBlock({ number, title, subtitle, description, categories, cta }: ServiceBlockProps) {
  return (
    <div className="py-20 border-t border-[#1a1a1a]">
      <div className="max-w-6xl mx-auto px-6">
        <span className="service-number font-mono text-sm text-[#555555]">[{number}]</span>
        <h3 className="service-title text-4xl md:text-5xl font-light text-white mt-4 tracking-tight">
          {title}
        </h3>
        <p className="service-subtitle text-lg text-white/90 mt-4">{subtitle}</p>
        
        <div className="grid md:grid-cols-2 gap-12 mt-10">
          <p className="service-desc text-[15px] text-[#8a8a8a] leading-relaxed">
            {description}
          </p>
          <div className="service-cats">
            <span className="font-mono text-[11px] tracking-[0.08em] text-[#555555] uppercase">
              Categories
            </span>
            <ul className="mt-4 space-y-2">
              {categories.map((cat, i) => (
                <li key={i} className="cat-item text-sm text-[#8a8a8a] font-mono">
                  <span className="text-[#555555] mr-2">{String(i + 1).padStart(2, '0')}.</span>
                  {cat}
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        <MagneticButton 
          strength={0.3}
          className="service-btn mt-10 inline-flex items-center gap-2 px-5 py-2.5 border border-[#333] rounded-md text-sm font-medium text-white hover:bg-white hover:text-[#050505] transition-all duration-300"
        >
          <ArrowUpRight className="w-4 h-4" />
          {cta}
        </MagneticButton>
      </div>
    </div>
  )
}
