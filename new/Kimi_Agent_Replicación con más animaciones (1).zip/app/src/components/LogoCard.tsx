import { useRef } from 'react'
import gsap from 'gsap'

interface LogoCardProps {
  children: React.ReactNode
}

export function LogoCard({ children }: LogoCardProps) {
  const cardRef = useRef<HTMLDivElement>(null)

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return
    const rect = cardRef.current.getBoundingClientRect()
    const x = (e.clientX - rect.left) / rect.width - 0.5
    const y = (e.clientY - rect.top) / rect.height - 0.5
    
    gsap.to(cardRef.current, {
      rotateY: x * 10,
      rotateX: -y * 10,
      duration: 0.4,
      ease: 'power2.out',
    })
  }

  const handleMouseLeave = () => {
    if (!cardRef.current) return
    gsap.to(cardRef.current, {
      rotateY: 0,
      rotateX: 0,
      duration: 0.6,
      ease: 'elastic.out(1, 0.5)',
    })
  }

  return (
    <div 
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="bg-[#0a0a0a] border border-[#1a1a1a] rounded-lg h-[120px] flex items-center justify-center px-6 transition-colors duration-300 hover:border-[#444] hover:bg-[#0e0e0e] cursor-pointer"
      style={{ transformStyle: 'preserve-3d', perspective: '500px' }}
    >
      <div className="text-white/80 font-bold text-sm tracking-wider transition-transform duration-300 hover:scale-105">
        {children}
      </div>
    </div>
  )
}
