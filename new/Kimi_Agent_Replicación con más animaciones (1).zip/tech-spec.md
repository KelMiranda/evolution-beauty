# Aracari Studios - Technical Specification

## Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| react | ^18.3.1 | UI framework |
| react-dom | ^18.3.1 | React DOM renderer |
| typescript | ^5.6.0 | Type system |
| vite | ^6.0.0 | Build tool |
| tailwindcss | ^3.4.0 | Utility CSS |
| gsap | ^3.12.0 | Animation engine |
| @gsap/react | ^2.1.0 | GSAP React integration |
| lucide-react | ^0.400.0 | Icons (arrow icon for CTAs) |

## Component Inventory

### Layout Components

| Component | Source | Reuse |
|-----------|--------|-------|
| Navbar | Custom | Single instance, fixed position |
| Footer | Custom | Single instance |

### Sections

| Component | Notes |
|-----------|-------|
| HeroSection | Complex layout with left service panel, right headline, vertical text animation |
| MissionSection | Text gradient + staggered client logo grid |
| ServicesSection | 3 service blocks with shared ServiceBlock sub-component |
| WorkSection | Section header + 3 ProjectCard components |
| TestimonialsSection | 4 testimonial cards in staggered grid |
| CTASection | Marquee text + rotating circular badge |

### Reusable Components

| Component | Source | Used By |
|-----------|--------|---------|
| SectionLabel | Custom | All sections — mono uppercase label with bracketed counterpart |
| ServiceBlock | Custom | ServicesSection (x3) — numbered title, description, categories, CTA |
| ProjectCard | Custom | WorkSection (x3) — bg image, overlay panel with tags |
| TestimonialCard | Custom | TestimonialsSection (x4) — quote, avatar, name, title |
| LogoCard | Custom | MissionSection (x6) — bordered card with centered logo image |

## Animation Implementation

| Animation | Library | Implementation Approach | Complexity |
|-----------|---------|------------------------|------------|
| Section entrance (fade + translateY) | GSAP ScrollTrigger | Batch animation on scroll into viewport, staggered children | Medium |
| Hero vertical text | CSS | Vertical writing-mode with character-by-character layout | Low |
| Nav scroll background | CSS + React state | scroll listener toggles class at threshold | Low |
| Marquee CTA text | CSS | translateX keyframe, duplicate content for seamless loop | Low |
| Rotating contact badge | CSS | rotate keyframe animation, 20s linear infinite | Low |
| Card hover lift | CSS | translateY transition on hover | Low |
| Button hover fill | CSS | Background-color + color transition | Low |
| Live clock | React state | setInterval updating time string | Low |

## State & Logic

- **LiveClock**: Custom hook `useLiveTime(timezone)` returning formatted time string, updates every minute
- **Scroll detection**: Custom hook `useScroll(threshold)` returning boolean for nav background toggle

## Other Key Decisions

- **No shadcn components needed**: This is a highly custom design with unique visual language; standard UI primitives don't apply
- **Single-page architecture**: All sections on one page with anchor navigation
- **Image assets**: Client logos, project backgrounds, and author photos stored in `public/images/`
- **Responsive strategy**: Mobile-first adaptation with stacked layouts below 768px, reduced typography sizes
